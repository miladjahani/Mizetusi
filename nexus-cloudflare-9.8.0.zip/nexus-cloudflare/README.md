# NEXUS · Xray control plane v9

NEXUS is a Python/FastAPI + Xray-core control plane. It creates real Xray users, publishes
subscribable nodes (the deployment's own direct node + healthy Cloudflare clean IPs), measures
every node with a real probe, and gives each end user a public status window with a dedicated
subscription per client.

It runs anywhere the image runs, and none of those places is privileged: a VPS or any Docker
host, a PaaS (Railway, Render, Fly, Koyeb, Heroku), a Cloudflare Container behind a Worker, or a
machine you already own behind a Cloudflare Tunnel. `app/runtime.py` is what adapts it to each
one — which raw ports exist, which hostname clients should reach, and where data can be written —
and the panel names the platform it is actually on rather than the one it was first built for.
The Railway-specific code (`app/railway.py`, the TCP-proxy pass) is inert without a Railway API
token, so a standalone deployment never touches it.

## What this release changes

- **The panel is a complete address of its own: `/admin`, opened through the edge.** The whole
  application is mounted a second time (`PANEL_PREFIX` in `app/main.py`) — the login page, the panel,
  its API, the static assets and the portal all answer under `/admin`, and the front end rides the
  same prefix, so a deployment's main address can stop being `/`. That matters for the same reason
  the low-fingerprint work does: a panel whose admin page *is* the front door of its own domain is
  one every scanner and every fingerprinting probe already knows, while `/admin` is a path nothing
  has reason to guess.
  * **The root is deliberately not taken away.** The Telegram WEB proxy loads `/?bridge=<capability>`
    in a hidden WebView, and every subscription / status-window link an admin has already handed to
    a user points at the root — so both keep working exactly as before, and the same app object
    serves both, with the same session cookie and the same admin header (`tests/test_panel_path.py`).
  * **A session hop stays on the prefix.** An anonymous `/admin` lands on `/admin/login` instead of
    being bounced to the root, where the address bar would be showing a different page than the one
    that was asked for.
  * **The edge opens that address.** The bundled `Caddyfile` routes `/admin/*` and the client paths
    through the proxy with HTTP/3 and HSTS, and `deploy/nginx.conf.example` is the same shape for a
    host that already terminates TLS with nginx. With the proxy up, the app's own port can be bound
    to loopback (`127.0.0.1:8080:8080`) so nothing reaches the panel except through it.

- **The Docker deployment stops announcing itself, and the panel can be served over real TLS
  without a CDN in front.** Advanced obfuscation hides the *traffic*; this hides the *service* behind
  it, because a panel is a fingerprint even when only its owner knows the URL. Four cheap signals
  went away, each a switch in the new **کم‌ردپا** card rather than a hard-coded rule
  (`app/core/stealth.py`):
  * **no `Server` header.** uvicorn sends `Server: uvicorn` on *every* response; the one middleware
    removes it (and `X-Powered-By` and friends) on the panel, the portal, the subscriptions and the
    static assets alike, and `--no-server-header` in the `Dockerfile` stops it at the source. An admin
    who wants a plausible name instead of silence sets one — a header value is validated to be a
    single short line, because a newline there is a response-splitting primitive, not a typo.
  * **`/docs` and `/openapi.json` are 404** until switched on. The OpenAPI document is a map of
    every route this product has — free reconnaissance for anything that can reach the address — and
    even when the switch is on, the document no longer carries the product's own title.
  * **`/health` answers `{"ok": true}`** to anyone outside the container. The full body (service
    name, database, uptime) is still served to a **loopback** caller, which is exactly how a Docker or
    Render health check asks; a forged `X-Forwarded-For` buys nobody the same thing, so a proxy
    header is not trusted as proof of anything here.
  * **the `X-NEXUS-*` subscription headers** stay on by default (they are diagnostics on a route
    that needs the token) and one switch drops them. The three headers a *client* reads
    (`profile-update-interval`, `subscription-userinfo`, `profile-web-page-url`) are never touched —
    hiding those would break the user's own subscription screen.
  * **The container itself** now drops every Linux capability except `NET_ADMIN` (which only the WARP
    exit asks for), runs with `no-new-privileges`, a `pids_limit` and a small `noexec` `/tmp`; and an
    opt-in `edge` service (`docker compose --profile tls up -d`, see the new **`Caddyfile`**) puts
    real TLS with HTTP/3 and HSTS in front, so the panel and the WebSocket edge stop crossing the
    network in the clear. See `tests/test_stealth.py`.

- **Advanced obfuscation, as a real capability rather than a roadmap line: XHTTP, gRPC and
  HTTPUpgrade behind Reality, each on its own public TCP port.** The panel used to *list* those
  transports as «در انتظار پورت اختصاصی» — declared, never built, never dialable. They are served
  now (`app/subscriptions/obfuscation.py`): one Xray inbound per transport, one port per transport
  (10101 gRPC, 10102 HTTPUpgrade, 10104 XHTTP, 10105/10106 the VMess and Trojan gRPC shapes), each
  published in **every** format — the sharing URI, sing-box, Clash/Mihomo, Xray JSON and the
  per-node link drawer. Three rules keep it honest rather than impressive, and they are the whole
  design:
  * **off until asked.** A deployment that starts answering on five extra public ports nobody
    requested is a deployment whose address a censor can recognise, so every transport is a switch
    an admin flips («مبهم‌سازی پیشرفته» in the «پیشرفته» tab).
  * **published only when *its own* port is really reachable.** On Railway a TCP proxy allocates
    the public number at random and only `app/ports.py` learns it, so a transport whose proxy is
    missing is withheld and the card names that one missing step — a link for a port nothing
    forwards is exactly the failure this feature exists to avoid.
  * **the plain Reality node is never the casualty.** The advanced half is the newest inbound, so
    the startup ladder drops *it* first (`_config(advanced=False)`) before WARP, before the Telegram
    proxies and before the Reality listener itself.

  The same card owns the **link parameters** that make the disguise worth anything: the uTLS
  fingerprint, Reality's `spx` spider path, packet encoding (`xudp`/`packetaddr`), the per-user
  fragment length/interval, the TLS-in-TLS fragment mode and the TLS mask — plus **XTLS Vision** on
  the Reality inbound, off by default and validated against a closed list, because Xray validates a
  whole config at once and one bad `flow` would take every protocol down with it. `docker-compose.yml`,
  the `Dockerfile` and `scripts/install-vps.sh` publish the new ports so a VPS can actually reach
  them. See `tests/test_obfuscation.py` for the three ways the publish rule can be broken.

- **The whole panel can now run on Cloudflare itself — Worker *and* Container — with no Railway
  project and no VPS at all.** A Worker runs JavaScript only, so "the app inside the Worker" cannot
  exist for a Python/Xray control plane; Cloudflare's **Containers** are what does exist, and this
  release wires the app to them. `wrangler.jsonc` at the repository root builds this repo's own
  `Dockerfile` (Xray, sing-box, mihomo, mtg, mtproto-proxy, the FastAPI panel), pushes it to
  Cloudflare's registry and starts it as one instance, and `cloudflare-containers/worker.js` binds
  that container to the same proxy file the paste-into-the-dashboard deployment uses — so there is
  still exactly one proxy implementation and one test (`tests/worker_smoke.mjs` now drives *both*
  shapes, and a bound `NEXUS_CONTAINER` deliberately outranks a stale `NEXUS_ORIGIN`, because a
  container deployment has no other address for the Worker to reach). `app/runtime.py` learned the
  platform (Cloudflare injects `CLOUDFLARE_DEPLOYMENT_ID`), which is what keeps the panel honest
  about the one thing a container cannot do: it is reachable over HTTP and WebSocket only, so the
  WebSocket transports (VLESS/VMess/Trojan/Shadowsocks/WARP) and the Telegram WEB proxy are live
  while Reality, AnyTLS, TUIC, MTProto and the HTTP/SOCKS5 web proxies stay unpublished instead of
  being handed to users as dead links. Deploying it needs **no secret of any kind**: Cloudflare's own
  Git integration (`Workers & Pages → Create application → Import a repository`) builds the image in
  its own build environment and rolls the container out on every push to `main`, generating the
  deploy token itself — the Worker just has to be named `mizetusi`, the name this repository's
  `wrangler.jsonc` declares (change the two together if you called yours something else), and the
  account has to be on the **Workers Paid** plan: Containers exist only there, and on Free the whole
  build succeeds right up to the last second of the deploy and then dies on
  `/accounts/<id>/containers/me` with a token-shaped error that has nothing to do with the token.
  `package-lock.json` is committed so the build resolves the same
  `wrangler` and `@cloudflare/containers` every time. The panel signs its own sessions too
  (`bootstrap()` in `app/main.py` mints and stores a `jwt_secret` on first boot), so what is left is
  one login (`ADMIN_PASSWORD` unset means `admin`, changed from inside the panel) and the two facts
  the guide — `docs/CLOUDFLARE-DEPLOY-FA.md` — leads with: a container's disk is **ephemeral**, so
  the panel's database has to be a real Postgres (`DATABASE_URL`) to outlive a sleep or a deploy,
  and the Worker still needs a **custom domain**, because `*.workers.dev` is filtered in Iran.
  `sh cloudflare-containers/deploy.sh --db 'postgresql://…'` remains the manual path for a machine
  that has Docker.
- **A free deployment that really runs the panel: any always-on Linux box, published through a
  Cloudflare Tunnel.** Containers need the Workers Paid plan, and every free Docker host *sleeps*
  after a few idle minutes — which for this product is fatal rather than annoying, because Xray runs
  inside the same container, so a sleeping panel drops **every** user's tunnel, not just the
  admin's. So the third shape is the one that needs no plan, no card and no public IP at all:
  `cloudflared` dials *out* to Cloudflare and holds that connection open, so the host can sit behind
  NAT on a normal home connection while clients still reach Cloudflare's anycast addresses on a
  subdomain of a domain the account owns. `sh scripts/install-vps.sh --tunnel '<token>'` wires it in
  one command (it writes the token and the platform into `.env` and starts the opt-in `tunnel`
  profile in `docker-compose.yml`). `app/runtime.py` learned the matching platform, because the old
  behaviour was a lie with consequences: a NAT'd host running plain Docker reported `tcp: 'always'`
  and the panel published Reality and the other raw-TCP transports against an address no client
  could dial. It now reports HTTP/WebSocket only and withholds those cards — while
  `NEXUS_DIRECT_HOST`/`NEXUS_DIRECT_PORT` stay the deliberate opt-in for a machine that really does
  own a public port. See `docs/FREE-DEPLOY-FA.md` for the walkthrough, including why a tunnel does
  not carry raw TCP and what that leaves unavailable.
- **«The panel on the Cloudflare Worker, the app really on Railway» — now true for the links too,
  and the guide says the one thing that decides whether it opens at all.** A saved Worker URL is
  the address a filtered client can actually reach, so every link a user is handed — subscription,
  status window, download — is now built from the Worker host (`public_url`), and it outranks
  `PUBLIC_BASE_URL`; that setting keeps describing where the app runs, which is what the origin
  node, the clean-IP catalog and the Worker's own prefilled `ORIGIN_FALLBACK` are built from
  (pointing those at the Worker host would make the Worker call itself). The deployment guide in
  the Cloudflare tab — and `cloudflare-worker/README.md` — now puts the step that matters first:
  a Worker answers on `*.workers.dev` until it is given a **custom domain**, and that whole suffix
  is filtered in Iran, so a Worker left on its default hostname is just a second address that only
  opens through a VPN. Saving one is answered with a warning instead of a silent success.
- **A scan now proposes; the admin disposes.** The Node Catalog used to publish every address a scan
  found, so a public deployment grew nodes nobody had chosen. Now the **automatic** clean-IP catalog
  (`cloudflare-NN`) is parked as **candidates** — a new «نودهای اسکن‌شده» list in the Nodes tab — and
  an admin ticks the ones to publish. Two rules keep that safe rather than annoying: the deployment's
  own node is never a candidate (it is the guaranteed baseline of every subscription), and a node the
  admin already published stays published across a re-scan. Selection is strictly manual: a location
  the admin configured by hand (an edge source with a provider/host) is scanned exactly like the
  automatic clean-IP catalog, so it waits for the same pick — which is why an explicit per-location
  ping now measures **candidates** too: an admin has to see a scanned node answer before deciding to
  publish it. The panel can hand the decision back to the scan with the **«افزودن خودکار»** switch
  (`edge_auto_publish`), which publishes everything waiting the moment it is turned on. New endpoints
  `POST /api/nodes/select` and `POST /api/nodes/selection` — see `app/nodes.py` and
  `tests/test_panel_extras.py` for the two ways this could go wrong (publishing on its own, or
  re-parking a chosen node).
- **Every tab can reset itself to defaults.** One mapping (`SETTINGS_SECTIONS` in
  `app/panel_extras.py`) says which settings keys belong to which tab, and a **«بازگردانی پیش‌فرض این
  بخش»** bar injected by the shell (`GET /api/settings/sections`, `POST /api/settings/reset`) deletes
  exactly those keys. Resetting «نودها» can never quietly drop the brand colours an admin spent time
  on, because a tab only ever touches its own keys.
- **The subscription tab grew the four things a fleet needs.** A new **سابلینک پیشرفته** section
  combines: a **usage report** (per-user consumption, quota share and lifetime, ordered by usage,
  expiry or name); **alerts** that fire *before* the ceiling does — a user within N days of expiry or
  past a share of their quota, with the two thresholds stored as settings (`alert_expiry_days`,
  `alert_quota_percent`) and validated on write; **per-user link management** — one call
  (`POST /api/users/{username}/rotate`) mints a fresh token and makes every URL already shared
  worthless without touching quota or expiry; and **per-client fine-tuning**, which lets an admin point
  any client at a chosen subscription target and copy that link, stored as `client_target_overrides`.
  The numbers are computed server-side in `app/subscriptions/reports.py` and recomputed on every panel
  open, so an alert appears the moment it becomes true without a cron to maintain.
- **A subscription URL now drives the client's own screen — auto-update, live traffic and a way
  back to the status window.** A subscription is not only a body: the apps read three response
  headers to build their «subscription» tab, and all three were missing, so a user had to remember
  to press «update» and could not see their usage or reach their own status window from inside the
  app. `GET /sub/{token}` (and every per-node/`/feed` shape built on it) now sends
  **`profile-update-interval: 12`** (the client re-fetches every 12 hours on its own),
  **`subscription-userinfo`** (`upload`/`download`/`total`/`expire` — we meter one combined counter,
  so the whole usage is reported as `download` rather than inventing a split, `total=0` means
  unlimited and `expire=0` means no expiry, which is exactly how clients render those two), and
  **`profile-web-page-url`** pointing at this user's `/portal/<token>` — the «open web page» button
  a client shows next to the profile. `tests/test_subscription_client.py` pins the *values*, not
  just their presence: a wrong `total` is worse than none, because it paints a full bar and locks a
  working user out of their own profile.
- **Installing on a VPS is one command.** `scripts/install-vps.sh` is the deployment where every
  transport is actually available. It installs Docker + the compose plugin (Debian/Ubuntu), uses
  the checkout it is run from or clones the repo, writes a `.env` with a **generated admin password
  and session secret** — so a fresh host never boots on the shipped guessable default — builds and
  starts `docker compose`, prints the generated password once, and then either adds the ufw rules
  for the published ports or prints exactly which to open. `--domain` sets the host clients use,
  `--open-firewall` runs the ufw rules, `--no-build` reuses existing images. An existing `.env` is
  never overwritten, so re-running it on a live host cannot rotate a password out from under you.
  For the whole path end to end — picking a host, the domain, TLS through Cloudflare, migrating
  users and backups — see **[docs/VPS-DEPLOY-FA.md](docs/VPS-DEPLOY-FA.md)** (Persian).
- **Users can now talk back, and the panel can be handed to a crowd safely.** Sharing a
  deployment used to be listen-only: the status window showed a user their traffic and links, and
  there was no path back. The window now carries a **بازخورد و پیشنهاد** card (a category, an
  optional 1–5 rating, the message and an optional contact), and the panel's own dashboard carries
  the **بازخورد کاربران** inbox for it. That is one new capability split across the two trust
  levels the panel already had: `POST /api/feedback` is *public* — an end user has no login, so the
  subscription token in the body is what proves they are a real user of this deployment — while the
  inbox (`GET`/`POST`/`DELETE /api/feedback…`) is behind the admin session like every other panel
  route. The public write carries its own per-address limiter (`feedback_throttle`, 12/hour: a real
  person sending a few notes is never blocked, a script filling the inbox is), the category falls
  back to «دیگر» instead of rejecting a message that fits no bucket, a rating outside 1–5 is dropped
  rather than stored as sent, and a message shorter than three characters is refused. Rows are
  `new`/`read`/`done`, the inbox badges the new count, and `status`/`delete` are one tap each — see
  `app/feedback.py` and `tests/test_feedback.py`.
- **What «share it with many users» needs beyond the feature: the review.** Three things in this
  repo are fine on a single-admin deployment and wrong the moment the panel is on a public URL, and
  all three are now closed. The login/feedback limiter keyed its map by client address and never
  shrank it, so a public host could grow it without bound; it is now capped (`LoginThrottle.MAX_KEYS`)
  with a sweep on every write. Admin responses had no baseline headers; every response now carries
  `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer` and a `Permissions-Policy`
  (deliberately *no* `X-Frame-Options` — the panel is legitimately embedded in a cross-origin preview
  pane, and denying that breaks the admin's own login, not an attacker). And CORS now accepts the
  `X-Nexus-Session` header it was already documented to use. The one item that is **yours, not the
  code's** is the password: `app/config.py` ships `admin_password='admin'`, and bootstrap keeps it
  when no `ADMIN_PASSWORD` is set — so **set `ADMIN_PASSWORD` (long, random) before publishing the
  panel's URL**, which is exactly what `railway.json`/`render.yaml` ask for. Everything else about
  scaling is in **Deploy anywhere** below: `DATABASE_URL` for Postgres (SQLite is one file and one
  writer), and `audit_logs`/`traffic_events` as the two tables that grow without a retention pass.
- **Telegram's sponsored channel above the chat list — wired to the WEB proxy.** The row a
  Telegram user sees at the very top of their chats, above every folder («اسپانسر پروکسی»), is not
  a chat they joined: Telegram renders it from `help.promoData`, whose own description is «a set of
  useful suggestions and a PSA/MTProxy sponsored peer», and it only does that for a proxy it has
  been told to advertise. So the **پروکسی WEB** card now asks for exactly the two facts Telegram
  keys it on — the **promotion tag** @MTProxybot issues for a registered proxy (32 hex characters,
  validated before anything is written) and the **channel** the deployment points its users at.
  The tag is rendered into the `mtproto-proxy` config as `[server].tag`, the one file both halves
  of the relay read, and it covers a `tg://webproxy` user as well because their client reaches
  Telegram through that same MTProto data plane, over the `use_middle_proxy = true` transport
  Telegram hands sponsored peers over. No tag is no advertised peer, and the panel says which of
  the two it is rather than leaving an admin to guess: `webrelay.notes()` names the bot, the card
  marks the row as not being shown, and the status window hands out a tap-to-join `tg://resolve`
  link until then. The same card renders the **post for the channel** (`broadcast()`) from the link
  it is really serving, so spreading a WEB link cannot quote a secret that was rotated afterwards,
  and a **کانال اسپانسر** button sits next to the WEB link in every user's status window.
- **Telegram Desktop's WEB proxy — the one Telegram proxy that needs no raw port — and a panel
  that hands a user exactly one kind of Telegram proxy by default.** Telegram Desktop 7.1 added
  a fourth proxy type, `WEB`, and it is not a transport at all: a hidden WebView loads
  `https://<this-deployment>/?bridge=<capability>` and shuttles multiplexed MTProto frames over
  a same-origin WebSocket, so what a censor sees is a genuine browser TLS handshake followed by
  HTTP. Because the carrier *is* this deployment's own 443, it is the only Telegram proxy that
  works on a forwarder (Railway included, behind the Worker, on a CDN) with **no TCP proxy** —
  which is why the new **نوع پروکسی تلگرام** picker defaults to «فقط WEB» and the status window
  hands out the `tg://webproxy` link and nothing else. The WEB proxy itself is **off until an
  admin switches it on**: its carrier is the panel's own address, so a deployment that serves it
  unasked is one a network that blocks Telegram can recognise — and a recognised address is a
  panel that only opens through a VPN. The
  other three types stay maintained and are published again the moment an admin selects «همهٔ
  انواع». `app/telegram/webrelay.py` owns both halves — mtproto.zig's `mtproto-proxy web-relay`
  (the browser-facing WebSocket) and its loopback data plane, two processes of the same pinned
  binary run under the same supervisor discipline as the engines — serves the bridge page on
  *our* host (Telegram refuses a WEB link that names a port, so the link carries `server` and a
  `dd…` secret and nothing else), and stores that secret in the database so a redeploy does not
  reissue every link a user already added. Its tarball is checksum-pinned in the `Dockerfile` and
  copied into the image's *runtime* stage, the binary itself has to accept the rendered config
  before a process is replaced (`--check-config`, asserted by `tests/test_webrelay.py` against the
  real binary), and `tests/test_runtime.py` asserts that every binary path the app looks for is
  really in that image — the one gap a rendered-config test cannot see, which is exactly how this
  relay's own binary was once installed in a build stage and never copied where a client runs.
- **Telegram Desktop's WEB proxy now really connects — the page *and* the socket it opens,
  and a check that would have caught it.** The bridge page was served while the same-origin
  socket that page opens was answered with `404`, so the one Telegram proxy that needs no raw
  port loaded a page and connected nothing — a WEB link that looks right in every cheap test.
  The relay serves one site and picks it by the `Host` header, compared verbatim; the
  WebSocket client always writes the URL's host into that header and *appends* anything it is
  handed separately, so restoring the public host as an extra header sent the relay two `Host`
  values whose first was `127.0.0.1:<port>`. The carrier socket is now dialled on loopback and
  handed over already connected, with the URI naming the public host **without** a port
  (`webrelay._dial_relay`) — the only shape the relay accepts. The card's new **تست اتصال**
  button no longer answers «the port is bound»: it derives the bridge capability from this
  deployment's own secret exactly the way Telegram derives it, loads `/?bridge=<capability>`
  for our own host, reads the token that page carries, opens the same-origin socket with
  `tproxy-v1.<token>`, and reports the subprotocol the relay echoed back. `tests/test_webrelay.py`
  asserts that end to end against the real binary, alongside the two shapes that broke it: a
  handshake carrying exactly one `Host` header, and a page whose socket is refused being
  reported as a failure instead of a success.
- **On Railway the random TCP ports are created for you — and a fresh deployment switches nothing
  on by itself.** Every card that needs a raw port used to say «on Railway add a TCP proxy» and leave the
  number to the dashboard — but Railway allocates that public port **at random**, so the port a
  link must carry is not the port the container binds, and a link built from the listen port is
  a link that answers nothing. Two new modules close that gap. `app/ports.py` is the single place
  that answers «which port is this capability really published on» (one stored mapping, falling
  back to the listen port — which is why a VPS and a Railway deployment share exactly one code
  path); `app/railway.py` drives Railway's own GraphQL API (`tcpProxyCreate`, `tcpProxies`,
  `serviceInstanceRedeploy`) and `app/autoconfig.py` runs one pass at boot: it switches **nothing**
  on by itself — the WEB proxy it used to enable is carried by the panel's own domain, and a domain
  that serves Telegram-proxy traffic is the domain a network blocks, so a panel that switches it on
  unasked is a panel that only opens through a VPN — and, when a `RAILWAY_API_TOKEN` is
  present, creates one TCP proxy per enabled raw-port capability, records the forwarded
  host/port, and performs the single redeploy the API itself says a new proxy needs. Nothing is
  invented and no admin choice is overwritten: a switch the admin has ever touched is never
  flipped, an API failure is reported verbatim, and each half runs once (its marker is a
  setting). The marker means «the pass has **nothing left to do**», and that is true on the
  first boot now: the pass flips no switch of its own, so the WEB proxy stays a candidate the
  admin can turn on and a choice the admin has made — in either direction — is never touched
  again.
  A TCP proxy turned out to move the HTTP edge with it, which is now the third thing the
  pass owns: on Railway, the moment one exists, the service is handed that proxy's
  *application* port as `PORT` — and that port is the one Xray already listens on for Reality,
  AnyTLS or MTProto, so the panel came back up on a port somebody else owned, died on
  «address already in use» and crash-looped where no card can show the reason because there
  is no panel left. So the pass pins `PORT` to the port the edge is really on **before** the
  redeploy that would move it (`railway.pin_http_port` → `railway.set_variable`): a *stored*
  variable is not the one Railway rewrites, and this is measured on the deployment rather
  than assumed — the `Dockerfile` gives uvicorn the same two names in the same order
  (`NEXUS_HTTP_PORT`, then `PORT`, then `8080`) so the process that binds the port and the
  pass that pins it can never disagree. `tests/test_autoconfig.py` asserts the pin happens,
  that a pass which creates no proxy writes nothing, and that a pin that cannot be written is
  reported as a failure instead of a silent success.
  The new **پیشرفته → پیکربندی خودکار پس از استقرار** card shows the mapping, names
  the missing variables and re-runs either half on demand.
- **Telegram, three ways: an MTProto proxy, an HTTP/SOCKS5 web proxy, and `web.telegram.org`
  through your own domain.** Telegram is not a VPN and none of the three is a VPN transport,
  so each one gets the implementation it actually needs. **MTProto** is the `tg://proxy` link
  a user pastes into the Telegram app itself — nothing to install — served by `mtg`, the only
  implementation that still speaks the current FakeTLS handshake, whose pinned binary ships
  inside the image next to sing-box and mihomo. The secret is generated here (`ee` + 16 random
  bytes + the hex of the fronting name) and stored in the database, so a redeploy does not
  reissue every link a user already added; `mtg access` parses the rendered config before a
  process is started; and changing the fronting name reissues the secret, because the name
  lives *inside* it. The **HTTP/SOCKS5 web proxy** is what Telegram Desktop calls «custom
  proxy»: two Xray inbounds (`http` with `accounts`, `socks` with `auth: password`) carrying
  **one account per user** — their username and their one credential — so disabling a user
  revokes their proxy line with every other link and no two users share a password.
  **`web.telegram.org`** is served from this deployment's own domain at `/tg/…` by a
  host-allowlisted reverse proxy (`web.telegram.org`, `*.web.telegram.org`, `telegram.org`,
  `t.me` — and nothing else, because an open proxy is an SSRF hole), with a small shim that
  routes the app's runtime WebSocket and API calls through the same path: a plain path proxy
  loads the page and then never connects. The Cloudflare Worker forwards the same prefix, so
  the web app works from a clean Cloudflare IP when the panel's own address is blocked. All
  three are off by default, each is published only when its listener really runs **and** its
  port is reachable (a VPS owns its ports; on Railway every port needs its own TCP proxy),
  the card names whichever half is missing, and a «تست دسترسی سرور» button really fetches the
  app shell from here before anyone is told it works. See **Telegram proxies** below.
- **The boot crash is gone, and a bad response can no longer take a tab down.** The grouped
  navigation read `NAV_GROUPS` off the *store*, where it does not exist (`groups`/
  `groupMeta` live on the router), so `renderNav()` threw «Cannot read properties of undefined
  (reading 'map')» on every load, the toast carried that message and the sidebar — the phone
  bottom bar — never painted; the shell startup now also goes through `safe()`. The same
  class of bug is closed at the wire: the API client turns a 200 that is not JSON (`a proxy or
  captive portal answered instead of the API`) into one readable error instead of handing HTML
  to a view, and every payload-consuming render (node explorer, links drawer, live guide)
  validates its shape and shows an empty state. `tests/js_smoke.mjs` now resolves the ids the
  template defines, so render paths really execute — with an empty, a realistic *and* a hostile
  payload — instead of returning early on a null element.
- **The panel now looks like the mark it ships.** The brand is the lime shield-in-a-ring on a
  near-black green tile, and the whole theme follows it: `static/app.css` moved every token to
  that family (`--accent:#c9f24c`, `--accent-2:#5fce62`, near-black backgrounds, lime glow on
  hover/focus/active) and `scripts/make_icons.py` draws every PWA icon, the favicon and
  `static/icons/nexus.svg` from the same geometry (signed distance fields, no image library —
  re-run `python3 scripts/make_icons.py` after a brand change). No blue or violet survives in
  the shipped stylesheet, which `tests/test_node_scope.py` asserts.
- **No more long scrolling: five nav groups and collapsible everything.** The sidebar is
  `NAV_GROUPS` (نمای کلی / کاربران و نودها / شبکه و لبه / پنل و ظاهر / سیستم) and each group
  unfolds only the tabs it owns — on a phone the group heads *are* the bottom bar and the tabs
  open as a sheet above it. Inside a tab, `collapsePanels()` folds every heavy panel into a
  `<details class="acc">` card with one summary row (icon, title, hint, count), so
  Cloudflare/Advanced/Settings/Tools are a short stack of titled rows instead of a wall of
  boxes, and the new compact density keeps a phone screen from becoming a scroll.
- **Live guide (راهنمای زنده).** `GET /api/guide` answers «حالا چه کار کنم؟» from *real state* —
  is a Worker URL saved, how many edge locations exist, how many nodes answered a ping, does a
  user exist, is any of them scoped, what is the brand — and returns eight steps with
  `done`, the first unfinished one as `next`, a score, and per-tab tips. The topbar chip opens a
  drawer that ticks the steps off, points at the next one and carries the tip for the tab you
  are on. Nothing is stored: the checklist is re-derived on every request, so it cannot drift
  from the deployment.
- **Node scope: a user can get only the multi-location nodes, only your server, or one
  country.** One stored string per user (`metadata.node_scope`) decides which slice of the
  catalog their subscription publishes — see **Node scope** below.
- **Shadowsocks finally pings in every client, not only Happ.** The 2022 ciphers are what
  sing-box and mihomo parse best, but v2rayNG, NekoBox, Shadowrocket and every device that
  only learned SIP022 showed the Shadowsocks node greyed out. The classic AEAD method
  `aes-256-gcm` now ships first (`ss-classic`, `/ws/ss-classic` + `/cdn/ss-classic`), reached
  through `v2ray-plugin` exactly the way the working reference link does it —
  `mode=websocket;path=…;mux=0;host=…;tls` — and the 2022 cipher families stay right behind
  it. `tests/test_v9_features.py` decodes a real `ss://` link and asserts the method, the
  key and the plugin options.
- **Every node names its country.** `app/subscriptions/flags.py` maps a location slug, an
  English or Persian country name, a provider hostname — or a flag emoji read out of
  someone else's remark — to a flag, so a subscription entry reads `🇩🇪 آلمان · de-cdn-01`
  instead of a bare slug. `transports.node_flag`/`node_label` are the single place a link
  name is composed, so the «پرچم کشور روی نام نودها» switch in the new **شخصی‌سازی** tab
  governs links, panel lists and the status window together.
- **A Hysteria2 node, published only when it is real.** Hysteria2 is QUIC and has no Xray
  inbound, so the new **پیشرفته** tab stores *your* hysteria2 endpoint (host, port,
  password, SNI, `salamander` obfs, insecure) and publishes it as one extra entry — with its
  flag — across the line formats, sing-box and Clash, never into the Xray config (which has
  no such outbound) and never into a per-node subscription. A half-configured endpoint is
  refused rather than handed to users.
- **Two more engines, for the protocols Xray cannot serve at all.** AnyTLS and TUIC v5 have no
  Xray inbound — sing-box and mihomo are the only implementations — so both ship inside the image
  (versions pinned in the `Dockerfile`) and **پیشرفته → هسته‌های دوم** switches each protocol on,
  sets its public port and picks which of the two hosts it. A hosted protocol is not a bolt-on: it
  becomes an ordinary transport profile, so it flows through the same subscription generator, the
  same per-user credential, the node scope, every client format (lines, sing-box JSON, Clash YAML)
  and the status window, with one self-signed certificate minted for the SNI the links already
  carry. A protocol is published only when an engine is really running its listener *and* the host
  can expose that port, and the card names whichever of the two is missing (Railway forwards TCP
  only, so TUIC stays withheld there until a VPS or `NEXUS_UDP=1`). Both engines are off by
  default, `sing-box check` / `mihomo -t` validate the rendered config before a single process is
  replaced, and a config an engine refuses leaves the listener that is already serving running.
  `tests/test_cores.py` renders both engines' configs and — whenever a real binary is available —
  has the engine itself accept them and really starts and stops a listener.
- **The status window keeps its shape, but the client list is split by engine.** Every client
  belongs to a family (`app/subscriptions/clients.py`) and each family is one collapsed
  dropdown: Xray clients (v2rayNG, Exclusive, Streisand, Shadowrocket, V2Box, FoXray) get
  Base64/text, sing-box clients (Hiddify, NekoBox, Karing, sing-box) get JSON, and
  Clash/Mihomo clients (Bettbox, Clash Verge) get **YAML only** — a client can never be handed
  a format its engine cannot import. Alternate formats stay hidden behind a second collapsed
  list, the admin's preferred family is marked recommended, and the window still carries the
  smart link, the banner, the support link and the config counter (`config_count` /
  `max_configs`).
- **Clash/Mihomo is handed a real profile, not a JSON fragment.** `?target=clash` — and every
  Clash-family client link, `?target=bettbox` included — used to answer with
  `{"proxies": [...]}`: valid JSON that no Mihomo client can import, which is exactly what
  made that sublink look broken. The body is now standard Clash YAML. `mixed-port`, `mode`,
  `log-level`, `unified-delay` and the controller settings; a `dns` block (`fake-ip`, local
  resolvers plus an Iran-aware `fallback-filter`); the `proxies` list; `proxy-groups` with one
  `select` group on top whose members are the per-country `url-test` groups — named with the
  same country, flag and Persian name the node labels carry, so the panel's «پرچم کشور روی نام
  نودها» switch governs both — plus one automatic lowest-latency group over everything and
  `DIRECT` for bypass; and `rules` that send LAN and Iranian traffic direct, reject the
  ad/adult domains **only** when the user's own switches ask for it, and `MATCH` the selector.
  `app/subscriptions/yamlout.py` is the small dependency-free writer behind it: block style,
  indentless sequences (dashes at their key's indentation, the shape every working profile
  uses), a scalar quoted only when YAML would otherwise read it as something else, and empty
  mappings/sequences written `{}`/`[]` so they never become `null`. The document and its
  serialisation are deliberately separate (`generator.clash_document` / `clash_profile`), so
  the panel and the tests assert the structure instead of parsing the text back;
  `X-NEXUS-Format: clash` names the wire format for clients that switch on it; and
  `tests/test_clash_profile.py` round-trips the emitted YAML through a real parser (it skips
  when none is installed), checks no proxy name repeats — Clash keeps the last one silently —
  and proves every entry a group references really exists.
- **How many configs a user gets is now a number you set.** The create/edit form has a
  **تعداد کانفیگ** field (and «شخصی‌سازی» holds the default quick-create uses). The cap is
  applied in exactly one place (`entry_pairs`), so the line formats, Base64, sing-box,
  Clash and Xray all hand out the same set — a client importing two of them sees one list.
- **Real multi-location, from packs or from any subscription.** Edge locations are no longer
  Cloudflare-only: the provider catalog grew to nineteen (Akamai, Google CDN, Azure Front
  Door, Edgio, CDN77, StackPath, CacheFly, KeyCDN, Imperva, Sucuri, Verizon/Edgecast,
  CDNetworks, QUANTIL, ChinaCache…), the **پیشرفته** tab installs ready-made location packs
  (one clean domain per country, or your own domains), and «ورود از سابلینک» turns any
  `subs.bikara.net`-style subscription into locations — host, port and country read from the
  entries themselves. Every location publishes the whole protocol matrix with its own
  Host/SNI, and one location can be handed out on its own (`/sub/<uuid>?location=de`).
- **Multi-location *inside* Cloudflare.** A Cloudflare edge answers on one anycast network, so
  a clean-IP location used to be whatever single label an admin typed — every entry dialled
  the same addresses and a client showed one country for all of them. The
  **«کلودفلر — لوکیشن‌های چندگانه»** pack (the first card in **پیشرفته**) creates six
  locations that each own *one part of Cloudflare's published ranges* (`ranges` on the source),
  so the addresses differ per country and so does what a client's geo database reports. All of
  them front the origin with the same Host/SNI — your Worker or panel domain, which the pack
  resolves for you or takes from the field above the card — and the honest probe says which of
  them actually answers from this deployment's network. The grouping is measured rather than
  assumed: see the next point.
- **The country on a node is measured, not guessed.** A user reported a Cloudflare node whose
  Canadian flag sat on an address their own lookup called American, and they were right —
  sampling every range of the pack against three independent databases showed the six ranges
  that used to be «کانادا» answering «United States» on two of the three, and the range
  published as «اروپا (میلان/مادرید)» answering US *and* ES. `app/edge/geo.py` now asks
  `ipwho.is`, `ip-api` and `ipinfo` about **each address**, takes the majority, keeps a tie as
  *no answer* (the admin's label stays) and caches an address's country for good. A location's
  country is decided from a deliberately stable candidate set — what the admin typed plus one
  sample per range, not the addresses the last latency pass happened to prefer — so a label
  never flips because a different address became the fastest. If the data contradicts the
  label, `sources.align_labels` rewrites the location, which corrects the flag, the node names
  (`us-cloudflare-01`) and the per-country sublink together; an address that measures elsewhere
  is left out of that location instead of being handed to users under a flag it contradicts. A
  clean *domain* is never touched (the Iranian relay publishes six countries through one host
  on six ports — that label is intent, not a guess), a location an admin corrects by hand is
  pinned, and «تشخیص کشور آی‌پی‌ها» in the edge card runs the measurement on demand. The
  «اندازه‌گیری کشور از روی آی‌پی» switch in **شخصی‌سازی** turns the whole thing off, and the
  locations table shows the measured country in its own column when the two disagree.
- **The client address is resolved, not taken from a header.** Asked whether nginx could be
  added to the panel as another core, the honest answer is no: a *core* here is a protocol
  engine (Xray, sing-box, mihomo) and nginx carries none of these protocols, so it would
  publish exactly zero new nodes — while the one job it is normally used for (one TLS port for
  the panel *and* every transport) already exists, with Railway/Cloudflare terminating TLS and
  FastAPI bridging each WebSocket path to a loopback Xray listener. The nginx feature this
  deployment genuinely needed is `real_ip`, and it was wrong: the container started uvicorn with
  `--forwarded-allow-ips='*'`, which replaces the TCP peer with the **leftmost**
  `X-Forwarded-For` entry — and the leftmost entry is whatever the client sent. `app/main.py`
  keyed the login throttle (10 attempts / 5 minutes) *and* the audit log on that value, so a
  forged hop meant a fresh bucket per attempt, and Cloudflare's authoritative
  `CF-Connecting-IP` was ignored entirely. `app/core/clientip.py` now applies nginx's rule the
  way `set_real_ip_from` does: the chain is read only when the raw socket peer is a trusted
  proxy (loopback/private by default, plus any range the operator adds), `CF-Connecting-IP` is
  believed only when the peer really is Cloudflare (its published ranges are checked, because
  anyone can send that header), and the chain is then walked right-to-left for the first
  address that is not a trusted proxy. An untrusted peer's headers are ignored outright. uvicorn
  no longer overwrites the peer (cookie policy already reads `X-Forwarded-Proto` itself, so
  nothing was lost), and a new **«IP واقعی کاربر»** card in **ابزار شبکه** shows the address the
  panel acts on, the raw peer, the chain it refused to believe and which rule won — with a
  switch for the trust rule and a CIDR field — so a wrong trust decision is visible instead of
  being a black box nobody can correct.
- **Three new panel tabs.** **شخصی‌سازی** (the end-user experience: banner, support link,
  flags, recommended format, branding, default config count), **ابزار شبکه** (a multi-CDN
  scanner console, TCP/TLS reachability from the server, DoH lookup that bypasses a poisoned
  resolver, CIDR maths, subscription analysis and one-click "لوكيشن بساز از این سابلینک"),
  and **پیشرفته** (Hysteria2, location packs, subscription import, the transport truth — what
  the running engine really serves and what it withheld — plus Shadowsocks key rotation and
  a sync+ping button). All of it is wired in `static/js/app.js` with its own views.
- **Ready-made node examples.** The Nodes section has a **«نمونه‌های آماده»** button that
  creates nodes with genuinely different settings in one click: clean IPs of Cloudflare,
  Fastly, Gcore and آروان‌کلود, Cloudflare's alternative HTTPS ports (2053/2087/2096/8443), a
  clean domain, an IP/SNI pair from different ranges, a plain-WS fallback and the origin node
  itself (`app/edge/samples.py`). Each entry explains what it is for, defaults its Host/SNI to
  the domain the CDN really serves this deployment on (the Worker URL when configured), never
  overwrites an existing node, and is pinged the moment it is created.
- **It runs anywhere, not only on Railway.** The origin hostname, the raw TCP endpoint and
  the database directory are now resolved generically (`app/runtime.py`): Railway, Render,
  Fly.io, Koyeb, Heroku, Vercel, Replit and a plain VPS/Docker host, each with its own
  injected variables, plus generic `NEXUS_PUBLIC_DOMAIN` / `NEXUS_DIRECT_HOST` / `NEXUS_DIRECT_PORT`
  overrides. `render.yaml` and `docker-compose.yml` ship as ready blueprints. On a host that owns
  a public port (VPS/Docker/Fly) Reality switches itself on with no configuration at all; where
  no raw port exists (Render, Heroku) it stays unpublished instead of handing users a dead link.
- **Clean IPs and clean domains from anywhere — real multi-location.** The catalog is no longer
  Cloudflare-only: `app/edge/sources.py` knows Cloudflare, Fastly, Gcore, آروان‌کلود, Bunny and
  AWS CloudFront, plus hand-written IP/CIDR lists and clean domains. Every **source** is one
  location with its own Host/SNI, so `de-cloudflare-01`, `nl` or `ir-arvan` all publish the full
  protocol matrix, the panel groups them by location, and a user can subscribe to a single one
  (`/sub/<uuid>?location=de`). With no source configured the previous automatic behaviour is
  unchanged.
- **The protocol multi-select is never empty again.** The chips in the create/edit user
  form render from the settings catalog, and only the Settings section fetched it — so
  opening «ساخت/ویرایش کاربر» first (a very normal thing to do) showed an empty protocol
  box and the form refused to save. The users section now loads the catalog up front, the
  form waits for it before opening, and the chips fall back to the built-in
  VLESS/VMess/Trojan/Shadowsocks list if that request ever fails.
- **A user really does get every protocol.** The Xray inbounds used to filter users by the
  single `protocol` column, so a VLESS user's VMess/Trojan/Shadowsocks links were published
  but rejected by the engine. One credential is now registered on every inbound, and the
  panel's protocol field became a multi-select with all protocols on by default.
- **Shadowsocks is four ciphers, each a real client link.** AES-128-GCM, AES-256-GCM,
  ChaCha20-Poly1305 and the broadly compatible `chacha20-ietf-poly1305`, each with its own
  listener, its own key and its own subscription target across both edge path shapes, now
  published as SIP002 `ss://` links (with the `v2ray-plugin` WebSocket edge) instead of
  being visible only in the JSON formats.
- **Shadowsocks is served single-user, on purpose.** A multi-user Shadowsocks-2022 inbound is
  rejected by Xray for every method but `blake3-aes-*-gcm`, and a single rejected inbound
  used to abort startup and take *every* protocol down; clients also disagree about which key
  a user has to present. One key per cipher is accepted by every client, so the panel rotates
  keys per cipher (Settings → «چرخش کلید شادوساکس») to revoke a leaked link.
- **A transport the engine refuses can no longer kill the deployment.** The config is tried
  richest-first (full → without WARP/Reality → without the Telegram web proxies → Shadowsocks
  reduced cipher by cipher), and only the profiles the running engine really contains are
  published, so a subscription can never point at a listener that does not exist. The Telegram
  inbounds are the newest thing in that file, so they are the first rung dropped: a Telegram
  listener must never cost the VPN a transport.
- **The Cloudflare Worker proxies the whole matrix.** It only knew `/ws`, `/ws/vless` and
  `/ws/trojan`, so every VMess, Shadowsocks, CDN and WARP node 404'd behind Cloudflare whileworking on the Railway origin. It also forwards the real client IP, keeps the handshake
  headers the origin needs, and answers an unreachable origin with a JSON `502`.
- **A local end-to-end proof.** `scripts/e2e_tunnel_check.py` boots the generated server
  config, the FastAPI edge and one client outbound per published transport, then pushes a real
  HTTP request through every tunnel on a host that has Xray installed.
- **Freebuff-side hardening.** Edge routes and the Worker's path table are now generated from
  (and asserted against) the transport profile table, and two new headless probes cover them:
  `tests/worker_smoke.mjs` and the protocol/Shadowsocks cases in `tests/test_panel_api.py`.
- **The Cloudflare Worker now fronts the panel, not only the relays.** Pages, the API,
  subscription and portal links, uploads, redirects and the panel's own WebSockets are proxied
  to the same origin, so a filtered network that can only reach Cloudflare keeps the whole panel
  and its node links together on one clean address. Absolute redirects naming the origin are
  rewritten to the Worker host, `X-Forwarded-Host` makes the origin build its links from that
  host, and an unknown `/ws/…` or `/cdn/…` path still answers 404, so the panel route list can
  never swallow a client's typo'd node path.

## What v7 changes

- **Object-oriented structure.** The backend is a small service layer
  (`SettingsStore`, `SessionManager`, `LoginThrottle`, `AuditLog`, `NodeCatalog`,
  `NodeProbe`) instead of loose module functions, and every route delegates to it.
- **The front end is real ES modules.** `static/js/app.js` is the single entry point and
  imports the core, API client, session manager, router, PWA manager and the four view
  classes. No bundler, no CDN, and no cross-file globals — the class of
  duplicate-declaration crashes the old five-script bundle could hit is gone.
- **A crashed view is no longer fatal.** Every render and every handler runs through
  `NexusApp.safe()`; window `error`/`unhandledrejection` are captured and surfaced as a
  toast, and the shell keeps working.
- **Installable app (PWA).** Dynamic manifest, service worker, and a generated NEXUS icon
  set (192/512/maskable/apple/favicon + vector logo). Install it on a phone or desktop with
  the «نصب برنامه» button in the topbar or in Settings.
- **A deploy can never leave a phone on the old build.** `/sw.js` is served with a build
  token hashed from the shipped assets, so a new deploy installs a new worker, drops the old
  shell cache and reloads the open panel exactly once. The Settings → سیستم card shows the
  running `version · build` so it is obvious which copy a device is painting.
- **Sessions no longer log you out.** The lifetime is an admin setting (default 7 days,
  up to 365), remember-me extends it to 30 days, the token is kept in durable storage so a
  phone reload survives a blocked cookie, and a 401 raises **one** in-panel re-login overlay
  instead of a toast storm plus a redirect loop.
- **The Node Catalog self-heals.** Railway's injected public domain (or the configured base
  URL) creates the `railway-direct` node at boot and whenever the panel is opened, so a
  fresh deployment never publishes an empty catalog or 404s a subscription.
- **Cloudflare nodes build themselves, with no admin action.** Boot seeds Cloudflare's
  published CIDRs, then the edge is detected by dialling a clean IP with the panel's own host
  as SNI; a configured Worker URL simply wins over that. Detection and the catalog rebuild
  tolerate a deployment where nothing has been probed yet, so the clean-IP nodes (and their
  real ping) exist before anyone opens the Node Catalog.
- **The layout fits every screen.** Grid/flex children can shrink (`min-width:0`), long
  subscription URLs wrap over two clamped lines instead of pushing the panel sideways, node
  rows move their action buttons to a second line, and tables reflow cell-by-cell under
  700px — all of it asserted by the stylesheet test.
- **Settings grew up.** Session length, automatic ping interval, app name and both theme
  accent colours are validated settings, and the client download links stay editable at
  runtime.

## Architecture

### Backend

| Module | Responsibility |
| --- | --- |
| `app/main.py` | FastAPI routes; delegates to the services below |
| `app/core/settings_store.py` | `SettingsStore` — typed access to the `settings` table |
| `app/core/security.py` | `SessionManager` (signed sessions + cookie policy), `LoginThrottle` |
| `app/core/clientip.py` | The real client address behind proxies — nginx's `real_ip` rule (trusted peers, `CF-Connecting-IP`, right-to-left chain) |
| `app/services/audit.py` | `AuditLog` — append-only admin trail with Persian labels |
| `app/nodes.py` | `NodeCatalog` (CRUD/sync/bootstrap) and `NodeProbe` (real latency) |
| `app/subscriptions/generator.py` | Subscription rendering for every target/format, and the Clash profile document (proxies + groups + rules) |
| `app/subscriptions/yamlout.py` | The small block-style YAML writer the Clash/Mihomo profile is serialised with |
| `app/subscriptions/flags.py` | Country → flag lookup for node names (slug, name, provider or emoji) |
| `app/api_extra.py` | The newer admin APIs: customization, Hysteria2, location packs, network tools |
| `app/edge/packs.py` | Multi-location packs + the subscription importer |
| `app/subscriptions/transports.py` | Transport profiles and the Shadowsocks cipher table |
| `app/subscriptions/clients.py` | Client catalog + the Iran-ready quick-create presets |
| `app/xray.py` | Xray-core supervisor: config generation, reload, StatsService sync |
| `app/telegram/mtproto.py` | The MTProto proxy: `mtg` config, secret lifecycle, real `mtg access` validation, supervisor |
| `app/telegram/webrelay.py` | Telegram Desktop's WEB proxy: `mtproto-proxy web-relay` + its loopback data plane, the bridge page and its same-origin socket, the `dd…` secret |
| `app/telegram/webproxy.py` | The HTTP/SOCKS5 web proxies: Xray inbounds, one account per user, port reachability |
| `app/telegram/webapp.py` | `web.telegram.org` through this domain: host allowlist, HTML/redirect/cookie rewriting, runtime socket tunnel |
| `app/telegram/service.py` | The four in one mode/status/payload/reconcile loop, for the panel and the status window |
| `app/autoconfig.py` | The one-time deploy pass: switch on what needs no decision, create the Railway TCP proxies the raw ports need (pinning the HTTP edge port first), and say what is left |
| `app/ports.py` | Listen port vs *published* port: the stored mapping every link is built from (falling back to the listen port on a host that owns its ports) |
| `app/railway.py` | Railway's TCP proxies from the panel: create/list/redeploy over the GraphQL API, plus the stored variables that keep the HTTP edge off a raw port (`pin_http_port`), with every failure returned as a readable reason |

Xray is the protocol engine while FastAPI stays the public HTTPS/WebSocket edge on whatever
host this runs on: the edge terminates TLS and bridges WebSocket streams to the loopback
Xray listeners. `app/runtime.py` answers "where am I, what is my public hostname, is there a
raw TCP port, which directory is writable", and `app/edge/sources.py` owns the clean-IP
providers, the clean domains and the locations they form.

### Front end (`static/js/`)

| Module | Class(es) |
| --- | --- |
| `core.js` | DOM/format helpers, `SafeStorage`, `Fmt`, `ToastCenter`, `EventBus` |
| `ui.js` | `ModalManager`/`Modal`, hand-rolled SVG `Charts`, `StatusKit`, `accordion()`/`collapsePanels()` |
| `session.js` | `SessionManager` — cookie/token/session recovery |
| `api.js` | `ApiClient`/`ApiError` — timeouts, JSON, single-flight 401 |
| `store.js` | `PanelStore` state container, `Router`, `SECTIONS`/`NAV_GROUPS` |
| `pwa.js` | `PwaManager` — service worker + install prompt |
| `views/*.js` | `DashboardView`, `NodesView`, `UsersView`, `TelegramView`, `CloudflareView`, `CustomizeView`, `ToolsView`, `AdvancedView`, `SettingsView`, `GuideView` |
| `app.js` | `NexusApp` — wiring, loaders, clock, polling, auth recovery |

#### Keeping a tab one screen long

Every tab is a stack of collapsed cards (`accordion()` folds the panels that were
already in the HTML, so ids, buttons and rendered content stay where they are), the
sidebar is five collapsible groups over the eight sections, and the lists that can
grow without bound render a page at a time:

* users and nodes paint `userLimit`/`nodeLimit` (24) rows and end in a single
  «نمایش بیشتر» row that names how much is left — a catalog of 300 clean IPs is one
  page, not a scroll;
* searching or changing a filter resets the page to the first screenful;
* the Cloudflare IP table keeps its existing «۲۰/۵۰/۱۲۰ ردیف» selector (the count is
  asked of the server, so it stays cheap);
* the per-client sublinks and the alternate formats are inside collapsed `<details>`
  dropdowns grouped by engine family (Clash/Mihomo · Xray · sing-box · core · tools),
  so a client that imports YAML is never shown next to a Base64 link.

## Session model

1. The primary session is an HttpOnly cookie. On HTTPS same-site requests it is
   `SameSite=strict; Secure`; embedded cross-site panes get `SameSite=None; Secure`
   (the only policy a browser will send back there).
2. Login also returns the signed token, which the panel stores and sends as
   `X-Nexus-Session`. That keeps the panel authenticated when the browser refuses the
   cookie entirely.
3. A 401 stops polling, shows a re-login overlay (page state preserved) and never
   redirects in a loop. Rotating the secret in Settings logs every device out on purpose.

## Nodes and probing

The Node Catalog is fully self-building — no admin action is ever required:

- The origin node (`railway-direct`, `render-direct`, `vps-direct`… depending on the platform)
  is created automatically from `PUBLIC_BASE_URL`, the platform's own variable, or the saved
  base URL. It is the one node that is never dropped after a failed probe, so a subscription
  can never come back empty.
- Edge nodes are rebuilt automatically too. When locations are configured they define the
  catalog; otherwise the Worker host wins, and failing that, if the panel's own domain is
  served through Cloudflare (custom-domain setups), NEXUS detects that with one TLS handshake
  against a healthy clean IP (SNI = panel host) and publishes the CF nodes with no user input.
- The catalog rebuild runs at startup, on every panel open, on «Sync نودها», and on a
  ~10-minute background loop; the ping loop keeps every latency fresh.
- Latency convention: `NULL` never probed, `>= 0` measured, `-1` last probe failed.
  Subscriptions are ordered fastest-first; a failed clean-IP node is dropped, but the
  Railway origin always stays published (DNS still resolves during a transient failure),
  so a subscription can never come back empty.
- Probes run on demand («پینگ همه نودها», per node, or «پینگ» on any location) and on a
  background loop whose interval is the `ping_interval` setting.
- **A ping is the client's own handshake.** For a TLS node health means a completed TLS
  handshake with that node's own Host/SNI — the check a client performs when it pings an
  entry. A bare TCP connect is measured and reported too (`ping_tcp`), but it is never
  health, so a location whose Host/SNI its addresses cannot serve is marked broken (and
  dropped from subscriptions) instead of being advertised as healthy and timing out in
  every client. When a certificate does not verify but the handshake completes, the node
  stays published and the panel says so.

## Transports — one node, every protocol

A subscription entry is a **(node × transport profile)** pair, defined once in
`app/subscriptions/transports.py` and consumed by the Xray config, the generator and the
panel. Every node publishes all of these **by default**, with no admin action:

| Profile | Protocol | Transport | Where it runs |
|---|---|---|---|
| `vless-ws` / `vless-cdn` | VLESS | WebSocket + TLS | `/ws/vless`, `/cdn/vless` |
| `vmess-ws` / `vmess-cdn` | VMess | WebSocket + TLS | `/ws/vmess`, `/cdn/vmess` |
| `trojan-ws` / `trojan-cdn` | Trojan | WebSocket + TLS | `/ws/trojan`, `/cdn/trojan` |
| `ss-ws` / `ss-cdn` | Shadowsocks-2022 · AES-128-GCM | WebSocket + TLS | `/ws/ss`, `/cdn/ss` |
| `ss-aes256-ws` / `ss-aes256-cdn` | Shadowsocks-2022 · AES-256-GCM | WebSocket + TLS | `/ws/ss-aes256`, `/cdn/ss-aes256` |
| `ss-chacha-ws` / `ss-chacha-cdn` | Shadowsocks-2022 · ChaCha20-Poly1305 | WebSocket + TLS | `/ws/ss-chacha`, `/cdn/ss-chacha` |
| `ss-legacy-ws` / `ss-legacy-cdn` | Shadowsocks · ChaCha20-IETF | WebSocket + TLS | `/ws/ss-legacy`, `/cdn/ss-legacy` |
| `vless-reality` | VLESS | Reality (TCP) | the direct port, when one exists |
| `warp-ws` | VLESS | WebSocket → WARP exit | `/ws/warp`, once WARP is enabled |

The two path shapes per protocol exist so a blocked path never takes the service down, and
Shadowsocks ships one listener per cipher family (each cipher needs a key of its own length,
so a single profile cannot represent them all). Each profile gets its own local Xray
listener; the FastAPI edge bridges each WebSocket path to the matching listener
(`EDGE_ROUTES`), so one Railway HTTP port serves all of them. Those routes are *generated*
from the profile table rather than hand-written, and the Cloudflare Worker's copy of the same
path list is asserted against it by `tests/test_panel_api.py` — a transport can therefore
never be published without a route on both edges.

### One credential, every protocol

A user is not tied to a single protocol. The `protocol` column holds a **set**
(comma-separated), every user is registered on **every** inbound by default, and the panel
renders it as a multi-select with all protocols switched on — so VLESS, VMess, Trojan and
all four Shadowsocks ciphers work for the same UUID/password with no extra step. VLESS, VMess
and Trojan keep one credential **per user** (disabling the user revokes it everywhere);
Shadowsocks authenticates one key **per cipher**, because Xray refuses a multi-user
Shadowsocks-2022 inbound for every method but `blake3-aes-*-gcm` and a single rejected
listener used to abort startup for the whole engine. Rotating those keys is therefore the SS
revoke path (Settings → «امنیت پنل»), and the panel reports which profiles the running engine
really serves so no link ever points at a listener that was dropped. Narrowing
the set is optional and only removes the links that were turned off (a subscription target
for a disabled protocol answers `400` instead of returning an empty list). Rows written by
older releases carry a single value, which still means "all protocols", because that is what
those users have always received.

**Reality** terminates TLS inside Xray with a real site's certificate, so it needs a raw
TCP endpoint: set `direct_host`/`direct_port` in the panel (or enable a Railway TCP proxy,
which Railway announces through `RAILWAY_TCP_PROXY_DOMAIN`/`RAILWAY_TCP_PROXY_PORT`). The
key pair is generated with the bundled binary and cached, and the profile appears in every
subscription the moment the endpoint exists.

**gRPC, XHTTP and HTTPUpgrade are deliberately not published.** Reality only accepts RAW,
XHTTP and gRPC clients, the h2-shaped transports need a dedicated port each (Reality
fallbacks are not honoured for them in Xray 26.9.9 — verified), and a Railway service can
expose exactly one raw TCP port. They are listed in the panel's transport view as
*planned* rather than shipped as links that dead-end.

**WARP** is opt-in on purpose. Register a peer in Settings → «نود WARP» (one anonymous
Cloudflare API call, from `app/warp.py`), then enable it: Xray gets a `wireguard` outbound
and the `/ws/warp` inbound is routed through it, so the WARP node is a real exit node. It
stays off until an admin turns it on because a WARP tunnel needs outbound WireGuard/UDP and
a node that silently dead-ends is worse than no node — `scripts/check_transports_e2e.py`
with `WARP_CONFIG` set proves the tunnel on the host that will run it.

**Amnezia** ships as a client profile (the Amnezia client imports the Base64 list and the
Reality profile). AmneziaWG itself is not an Xray protocol, so no Amnezia-specific inbound
is advertised.

## Telegram proxies

Telegram is not a VPN and none of these is a VPN transport, so each one is built out of what
actually implements it. Each is published only when its listener is really running **and** its
port is reachable from outside; the card names whichever half is missing instead of handing out
a link that dead-ends. A VPS owns its ports as soon as they are open; on Railway every published
port needs its own TCP proxy, whose public port is **random** — the panel creates those proxies
itself (`app/railway.py`, `app/ports.py`) rather than asking an admin to copy numbers between
two dashboards, and `RAILWAY_TCP_PROXY_*` is only the fallback it uses when no mapping exists.

All four ways are **off by default** on purpose — a host that cannot forward a raw port would only
show a card full of reasons, and the WEB way is carried by the deployment's own address, so a
deployment that serves it unasked is one a network that blocks Telegram can recognise and block in
turn. Switch it on from its own card and the WEB proxy becomes the one a user is handed: the
panel's **نوع پروکسی تلگرام** picker defaults to «فقط WEB» and the status window publishes
`tg://webproxy` and nothing else until an admin selects «همهٔ انواع» (with the WEB proxy off, the
status window grows no Telegram section at all rather than handing out a link that cannot work).

| Way | What the user gets | Port | Needs |
|---|---|---|---|
| WEB (`tg://webproxy`) | `tg://webproxy?server=<this-deployment>&secret=dd…` — added inside Telegram Desktop 7.1+ as proxy type **WEB** | the panel's own 443 | nothing extra — no raw port, no TCP proxy, works behind a CDN |
| MTProto | `tg://proxy?server=…&port=…&secret=…` — pasted into the Telegram app itself | 8446 | the `mtg` binary (shipped in the image) + a raw TCP port |
| HTTP web proxy | `http://user:pass@host:8448` — «Custom proxy» in Telegram Desktop, and a browser | 8448 | a raw TCP port |
| SOCKS5 web proxy | `socks5://user:pass@host:8449` | 8449 | a raw TCP port |
| `web.telegram.org` | `https://<this-deployment>/tg/…` — the web app served from here | the panel's own port | nothing extra |

### Telegram Desktop's WEB proxy (`tg://webproxy`)

Telegram Desktop 7.1 added a proxy type that is not a transport at all: **WEB**. The client
opens no MTProto socket, and a hidden native WebView loads a page **from this deployment** that
shuttles multiplexed MTProto frames over a same-origin WebSocket. What a censor sees is a real
browser TLS handshake with a CA-chained certificate and then ordinary HTTP — because it is one:

```
Telegram Desktop → hidden WebView → https://<this-deployment>/?bridge=<capability>
                 → same-origin WebSocket (/api/v1/socket) → relay → its loopback data plane → Telegram
```

The carrier is this deployment's own HTTPS name, so the WEB proxy is the one Telegram proxy that
needs no public raw port — Railway included, with no TCP proxy at all — which is why it is what a
user is handed by default.

`app/telegram/webrelay.py` owns both process halves, and they are the same pinned binary
(mtproto.zig's `mtproto-proxy`, shipped in the image) in two modes: `mtproto-proxy <config>` is a
data plane bound to `127.0.0.1` that only the relay dials, and `mtproto-proxy web-relay <config>`
is the WebSocket half. The relay prefixes every backend connection with a PROXY-v2 header, so
Telegram sees the real browser address and nothing untrusted can forge it. The config is
validated by the binary itself (`--check-config`) before a process is replaced, both halves start
and stop under the engines' supervisor discipline, and a change is picked up by the same
`telegram_sync_interval` loop. The panel forwards the bridge on our own host — Telegram treats the
page and its socket as one site, so the public Host is restored explicitly — and tunnels the
carrier's `Sec-WebSocket-Protocol` (`tproxy-v1.<token>`) untouched, without which the page loads
and then never connects.

*Restored explicitly* is a narrow claim, and getting it half right is what made the socket 404:
the relay serves exactly one site and compares `Host` verbatim, while the WebSocket client always
writes the URL's host into that header and appends anything it is handed separately. Our host is
therefore no longer passed as a header at all — the loopback socket is opened here and handed over
already connected, and the URI (`ws://<domain>/api/v1/socket`, **no port**) is what builds the one
`Host` header the relay routes by. The card's **تست اتصال** button runs the same two steps a
WebView runs (page, then `tproxy-v1.<token>` socket) and reports the subprotocol the relay echoed
back. `tests/test_webrelay.py` pins both halves, including against the real binary.

Two details are easy to get wrong and are asserted by `tests/test_webrelay.py`: the link carries
**no port** (Telegram refuses a WEB link that names one) and its secret is a **`dd…`** secret,
not the `ee` FakeTLS one — the relay is a raw byte pipe and adds no TLS-emulation record, and a
client handed an `ee` secret reports the proxy as unsupported. The secret is stored in the
database and rotated from the panel («چرخش secret»), which is what revokes every link already
handed out; the domain field stays empty by default so the link follows whatever hostname the
deployment is served on.

### MTProto (`mtg`)

Xray has no MTProto inbound, so this is the one place a second binary is genuinely required.
`mtg` is the implementation to use — it is the maintained one and the only one that still
speaks the current FakeTLS handshake — and its pinned release lives in the image next to
sing-box and mihomo. The panel owns the whole lifecycle: it generates the secret, writes
`/data/mtg.toml`, **validates it with the binary itself before starting anything**
(`mtg access`, whose parsed output is what the panel shows), runs it under the same
supervisor discipline as the engines, and re-syncs every `telegram_sync_interval` seconds so a
new user is on the listener without a reload.

The **secret is generated here and stored in the database** — `ee` + 16 random bytes + the hex
of the fronting name, in the format Telegram clients expect — so a redeploy does not reissue
every link a user already added. Because the fronting name lives *inside* that secret, changing
it reissues the secret; that is not a bug to paper over but the reason the name has to be a
hostname that really serves TLS. Settings → «پروکسی تلگرام» exposes the switch, the port, the
fronting domain, the DNS resolver (`https://1.1.1.1` by default — the panel's own resolution of
that name is what an active probe would compare against), the optional fronting IP for when
the name cannot be resolved locally, and the concurrency cap (8192 by default).

### HTTP/SOCKS5 web proxies

These are what Telegram Desktop calls «custom proxy»: one `host:port` plus credentials, not a
config list. They are **not** a new service — Xray, the engine this deployment already runs,
serves both inbound types with a real account list, so they ride along in the same config as
the transports and each profile gets its own listener (an HTTP inbound does not speak SOCKS5
and vice versa, and a client that wants one should not have to guess).

There is **one account per active user**: the username is the panel username and the password
is that user's own credential, so nobody shares a password, a leaked line can be revoked on its
own, and a user who is disabled loses their proxy line with every other link. Two listeners,
two profiles (`web-http` and `web-socks`), each with its own switch and port in the panel.

### `web.telegram.org` through your own domain

The web version of Telegram is a website, so the only way to unblock it is to serve it from a
host that is not blocked. `app/telegram/webapp.py` is a **host-allowlisted** reverse proxy for
exactly that: this deployment answers on `/tg/…` and forwards only `web.telegram.org`,
`*.web.telegram.org`, `telegram.org` and `t.me` — the allowlist is the point, because a
path-and-host proxy without one is an open relay. Redirects and cookie scopes are rewritten
back to our own domain, and a small shim injected into the page routes the app's own runtime
WebSocket and JSON API calls through `/tg/__ws/<host>/…` and `/tg/__p/<host>/…`: proxying the
HTML alone loads the page and then never connects, which reads as "it half works". The
Cloudflare Worker forwards the same prefix, so the web app also opens from a clean Cloudflare
IP when the panel's own address is blocked. The «تست دسترسی سرور» button really fetches the app
shell from here rather than trusting the configuration.

The tab is **پروکسی تلگرام** in the panel: its first card is the WEB proxy (the one a fresh
deployment switches on by itself), the **نوع پروکسی تلگرام** picker above it decides whether the
other three are published at all, and the status window gives each user their own lines — the
`tg://webproxy` link in the default mode, or the `tg://` link, both web-proxy links with their
credentials and the web app URL in «همهٔ انواع» — next to the VPN links they already had.

## Public endpoints

- Telegram: `tg://webproxy` (Telegram Desktop's WEB type — the bridge page and its socket are `/?bridge=…` and `/api/v1/socket` on the panel's own port) · `tg://proxy` (MTProto) · `http://user:pass@host:8448` · `socks5://user:pass@host:8449` · `/tg/…` (Telegram Web), including its own `X-NEXUS-` headers
- VLESS: `/ws/vless` · VMess: `/ws/vmess` · Trojan: `/ws/trojan` · WARP: `/ws/warp`
- Shadowsocks: `/ws/ss-classic` (AES-256-GCM, every client) · `/ws/ss` (2022 · AES-128-GCM) · `/ws/ss-aes256` · `/ws/ss-chacha` · `/ws/ss-legacy`
- CDN path shapes: `/cdn/vless`, `/cdn/vmess`, `/cdn/trojan`, `/cdn/ss-classic`, `/cdn/ss`, `/cdn/ss-aes256`, `/cdn/ss-chacha`, `/cdn/ss-legacy` · legacy `/ws`
- Subscription: `/sub/<UUID>?target=auto|all|vless|trojan|vmess|ss|base64|singbox|clash|xray|json`
- By transport: `?target=ws|cdn|reality|warp` or one exact profile, e.g. `?target=vless-cdn`
- Per-client: `/sub/<UUID>?target=bettbox|exclusive|nekoboxplus|v2rayng|hiddify|karing|streisand|shadowrocket|v2box|foxray|nekobox|amnezia|smart`
- Per-node: `/sub/<UUID>?target=vless&node=<node-name>` or `/sub/<UUID>/<node-name>`
- Status window: `/portal/<UUID>` (also `/portal/<username>` and legacy `/status/<username>`), data at `/portal/<UUID>/json`
- Panel API: `/api/metrics`, `/api/users`, `/api/users/<name>/links`, `/api/users/quick`,
  `/api/presets`, `/api/clients`, `/api/transports`, `/api/warp`, `/api/nodes`,
  `/api/nodes/ping`, `/api/nodes/sync`, `/api/settings`, `/api/logs`, `/api/backup`,
  `/api/core/status`, `/api/settings/rotate-shadowsocks`
- Newer admin API: `/api/customization`, `/api/hysteria`, `/api/edge/packs`,
  `/api/edge/import`, `/api/tools/check`, `/api/tools/dns`, `/api/tools/cidr`, `/api/tools/parse`,
  `/api/net/client-ip` (the resolver's verdict, and the trusted-proxy rule itself),
  `/api/cores` + `/api/cores/reload` (the second engines: the switch, public port and hosting engine
  of each hosted protocol, and the reconcile that starts or stops them),
  `/api/telegram` + `/api/telegram/probe` (the Telegram proxies: the published mode, switches, ports,
  the MTProto and WEB secrets/links, the running listeners' own parsed config, and the real fetch of
  `web.telegram.org` from this host),
  `/api/system/autoconfig` (what the one-time deploy pass switched on, the listen→published port
  mapping of every raw-TCP capability, which Railway variables are missing, and a re-run of either
  half — `action=switches|railway|all`)
- Cloudflare Worker: `/api/cloudflare/worker-code`, `/api/cloudflare/worker-download`, `/api/cloudflare/worker-test`
- PWA: `/manifest.webmanifest`, `/sw.js`, `/static/icons/*`

`target=auto` (and `all`, and the `smart` client) returns **every node × every transport**:
the default subscription already carries VLESS, VMess, Trojan and Shadowsocks for each node,
ordered fastest-node-first. `base64` is the same matrix encoded for the clients that only
read base64 blobs. Every response carries `X-NEXUS-Format`, `X-NEXUS-Node-Count`,
`X-NEXUS-Transports` and `X-NEXUS-Target`.

Shadowsocks is published as a **SIP002 link**: the method and key travel as base64 userinfo
and the WebSocket edge as the `v2ray-plugin` SIP003 plugin, which is what v2rayNG, NekoBox,
sing-box, mihomo and Shadowrocket all implement — so SS nodes appear in a client's config
list next to the other protocols and `?target=ss` returns links. A profile set with no link
form at all (Reality alone, on an install with no raw TCP port) still answers with the
sing-box JSON instead of a `400` that reads as "broken".

Because a Shadowsocks listener authenticates one key per cipher, that key is what a link
carries — disabling a user revokes VLESS/VMess/Trojan immediately, while Shadowsocks access
is revoked by rotating its keys (`POST /api/settings/rotate-shadowsocks`, or the button in
Settings → «امنیت پنل»), which reloads the engine so old links stop authenticating at once.

## The Cloudflare Worker

`cloudflare-worker/worker.js` is a narrow WebSocket reverse proxy (never a generic fetch or
open relay) so Iranian users can dial a clean Cloudflare IP while the traffic still ends in
the Railway container. It proxies **every** published path, not a hand-picked subset: a path
the panel hands out but the Worker refuses 404s behind Cloudflare while working onthe Railway origin, which reads as "the Worker is broken". It also **forwards `/tg/…` to the
origin unchanged** — method, query and body included — which is what makes the Telegram Web
proxy work from a clean Cloudflare IP; that prefix is a plain HTTP forward, so it is
deliberately outside the WebSocket-only path table, and it is the one path whose WebSocket
half (`/tg/__ws/…`) *is* in it. It forwards the real client IP as
`X-Forwarded-For` (so IP limits and quota attribution survive Cloudflare), keeps
`Connection: upgrade`/`Upgrade: websocket` (the origin's handshake requires both), and turns
an unreachable origin into a JSON `502` instead of letting the rejection escape into
Cloudflare's opaque error page. `/health?probe=1` makes the Worker dial the origin itself, so
the panel's «تست ورکر» button proves the Worker, the origin URL and the route in one call.

## Clients, presets and the quick-create button

`app/subscriptions/clients.py` holds the client catalog (import format, platform, download
link, notes) and the presets used by quick create. Client ids are accepted as subscription
targets, so every client gets its own URL — `/sub/<uuid>?target=bettbox` returns the Clash
profile (Bettbox is a Mihomo client, so it gets the whole YAML config), `?target=v2rayng`
returns the Base64 (V2Ray) list and
`?target=nekoboxplus` returns sing-box JSON — and `&node=<name>` narrows it to a single node.

Quick create precedence is request values, then the panel defaults, then the preset. Each
created user gets a status window at `/portal/<uuid>` listing the smart link, the per-client
subscriptions, the client download buttons and every node with its measured ping. Download
links are editable in Settings → «لینک دانلود کلاینتها» because stores and release pages move.

## Node scope

A multi-location install publishes a lot of nodes (this server's relay + every clean IP of
 every edge location). Which slice one user may see is an explicit choice, stored on the user
 in `metadata.node_scope` and understood everywhere by `app/subscriptions/scope.py`:

| Scope | What the subscription contains |
| --- | --- |
| `all` | every published node (the default — nothing changes for existing users) |
| `multi` | only the multi-location (edge) nodes, without this server's relay |
| `origin` | only this server's own relay |
| `cc:us` (or `cc:us,cc:de`) | only those countries |

Any spelling resolves to the canonical id: `us`, `USA`, `🇺🇸`, `آمریکا` and `de-frankfurt-01`
all become `cc:us`; `edge`/`locations`/`مولتی` become `multi`; an unknown word widens to `all`
rather than publishing an empty subscription. Where it is applied:

- **the subscription routes** — `?scope=` overrides for one link, and with no parameter the
  user's stored scope applies, so a link handed out earlier can never leak an excluded node.
  The response carries `X-NEXUS-Scope`, and a scope with no nodes answers `404` with a
  readable reason instead of a half-empty list;
- **`render()`** — when no node list is passed, the user's scope decides, so line, Base64,
  sing-box, Clash and Xray formats always contain the same set;
- **the panel** — the create/edit form has a scope picker (with the live node count of every
  choice), the quick-create cards pair a preset with the nodes it publishes (the
  `multi-location` and `origin-only` modes), «شخصی‌سازی» holds the default scope, and the link
  drawer shows which nodes are outside the scope plus a ready link for every other one;
- **the status window** — the user sees their scope and can switch it per link, one tap each.

`GET /api/scopes` (optionally `?username=`) returns the catalog with live counts, and
`GET /api/guide` the live setup guide. `tests/test_node_scope.py` covers the spellings, the
filter, every format, the endpoints and the guide.

## Deploy anywhere — Railway, Render, VPS

Deploy the repository with the included Dockerfile; the container starts FastAPI and
reconciles Xray-core automatically. A PostgreSQL database is recommended for production
(SQLite is used otherwise, on the mounted volume or in a local `data/` directory when the
volume is missing). Every platform supplies `PORT`.

The runtime layer detects where it is and adapts (`GET /api/system/runtime` shows what was
detected):

| Platform | Public hostname from | Raw TCP (Reality) |
| --- | --- | --- |
| Railway | `RAILWAY_PUBLIC_DOMAIN` / `RAILWAY_STATIC_URL` | only after a TCP Proxy is added |
| Render | `RENDER_EXTERNAL_URL` / `RENDER_EXTERNAL_HOSTNAME` | not on the free plan |
| Fly.io | `FLY_APP_NAME` (`.fly.dev`) | yes (TCP services are free) |
| Koyeb / Heroku / Azure | `KOYEB_PUBLIC_DOMAIN` / `HEROKU_APP_DOMAIN` / `WEBSITE_HOSTNAME` | no |
| VPS / Docker | `NEXUS_PUBLIC_DOMAIN`, else the machine's public IP | yes — auto-detected |

* **Render** — Render → New → Blueprint, then pick this repository (`render.yaml`). The disk
  needs a paid instance; without it the app stores sqlite in a local directory and still boots.
* **VPS** — `NEXUS_PUBLIC_DOMAIN=panel.example.com docker compose up -d --build`, then open
  8080 (panel + WebSocket edge) and 8443 (Reality) in the firewall — plus 8446 (MTProto),
  8448 (HTTP) and 8449 (SOCKS5) once the Telegram proxies are switched on, since each of them
  is a raw TCP listener and a closed port is exactly what "the card says published but nothing
  connects" looks like. `NET_ADMIN` is only needed by the optional WARP exit.
* **Railway (the TCP proxies, created for you)** — Railway gives a service HTTPS/443 and nothing
  else, so every raw TCP listener (Reality, AnyTLS, MTProto, the web proxies) needs a **TCP
  proxy** whose public port Railway picks at random. Set `RAILWAY_API_TOKEN` — a workspace token
  (`Authorization`) or a project token (`Project-Access-Token`); both headers are sent, so either
  kind works — and the boot pass creates one proxy per enabled capability, stores the
  listen→published mapping and redeploys the service once, which is what the API says a new proxy
  needs. `RAILWAY_PROJECT_ID` / `RAILWAY_ENVIRONMENT_ID` / `RAILWAY_SERVICE_ID` are injected by
  Railway itself; `NEXUS_RAILWAY_*` overrides them. With no token nothing is created and the
  **پیشرفته → پیکربندی خودکار** card names the missing variable instead of guessing a port.
* **Anywhere else** — set `NEXUS_PUBLIC_DOMAIN` (and `NEXUS_DIRECT_HOST`/`NEXUS_DIRECT_PORT` if
  a raw port is reachable) and run the image; nothing else is provider-specific.

> **Choosing a host.** NEXUS is a proxy/VPN control plane, and most PaaS acceptable-use
> policies forbid running one — Railway, Render and friends also watch for the outbound
> patterns a scanner produces, which is how a workspace can be restricted for "suspicious
> activity" minutes after a deploy. A VPS or dedicated server you control (Hetzner, Netcup,
> a provider in Iran) is the honest home for this software: one raw TCP port for Reality,
> no fair-use limits, and no third party inspecting your traffic. The defaults above
> (`scan_on_boot=0`, small batches, `NEXUS_OUTBOUND_PROBE_ENABLED=0` if the host must never
> see outbound measurement traffic) keep the footprint small wherever it runs.

### Ready-made nodes

The Nodes section can create a set of example nodes with one click:

| Sample | What it publishes |
| --- | --- |
| دامنهٔ تمیز | the deployment's own hostname as a node (what a custom domain behind a CDN needs) |
| Cloudflare · IP تمیز + Worker | a Cloudflare anycast IP with the Worker hostname as Host/SNI |
| Cloudflare · پورت‌های جایگزین | the same edge on 2053/2087/2096/8443, for networks that drop 443 |
| Cloudflare · IP و SNI متفاوت | an address from one range carrying another range's SNI |
| Fastly / Gcore / آروان | clean IPs of three more CDNs, each as its own location |
| بدون TLS · پورت ۸۰ | the same host over plain WebSocket, as a last resort |
| نود مستقیم (Origin) | the always-present origin node, if it was deleted |

Adding a sample never overwrites an existing node, and a sample node survives the automatic
catalog rebuild (only the rows the rebuild owns are reset). `POST /api/nodes/samples` with
`ids` (or `all: true`), `GET /api/nodes/samples` and `DELETE /api/nodes/samples` are the same
actions over the API.

### Outbound probing is quiet by default

Filling and measuring the clean-IP pool means opening sockets to third-party CDNs,
and doing that the moment the container boots is what gets a deployment flagged for
"suspicious activity" by a hosting provider. The defaults are therefore small and
explicit:

| Setting | Default | Meaning |
| --- | --- | --- |
| `cf_probe_limit` | `64` | addresses kept (and probed) per pass |
| `cf_probe_concurrency` | `8` | probes in flight at once |
| `scan_on_boot` (`NEXUS_SCAN_ON_BOOT`) | `0` | never seed the pool automatically at boot |
| `outbound_probe_enabled` (`NEXUS_OUTBOUND_PROBE_ENABLED`) | `1` | `0` stops every external probe and ping |

With the defaults a fresh deploy publishes only the origin node — which is a complete
subscription — and the admin scans a provider on demand from the panel (or presses
«اسکن همه providerها»). The «منابع لبه و لوکیشن‌ها» card shows the active scan mode and the
per-pass size, so the outbound footprint is visible rather than implicit.

### Edge sources (clean IPs, clean domains, locations)

The Cloudflare section of the panel has a **«منابع لبه و لوکیشن‌ها»** card. One source = one
location:

* **IP source** — pick a provider and press «اسکن همه providerها»; the published ranges are
  downloaded, sampled, TCP-probed and turned into nodes named `<location>-<provider>-NN`. Your
  own clean IPs (or CIDRs) can be pasted instead, under any provider or as `custom`.
  A provider whose pool is still empty is **filled on demand** the first time a location needs
  it (bounded, cached for five minutes), so a location added by hand publishes real,
  pingable addresses on a deployment that never ran a scan — `scan_on_boot` is off by default,
  and without this a location published *nothing at all* and therefore could not ping.
  A source may also carry **`ranges`** (up to 12 CIDRs): the location is then restricted to
  that part of its provider's network — a Cloudflare region — and its addresses never overlap
  another location's. Measured addresses inside the ranges come first; when a region has none
  yet, the location seeds itself from its own ranges and those addresses join the pool, so the
  next TCP pass measures them and the sync prefers the ones that answer. The pool probe visits
  never-measured addresses first (`app/cloudflare/monitor.py`), which is what stops a fresh
  range or manual IP from queueing behind the already-measured batch forever.
* **Domain source** — paste a clean domain (a custom domain behind Cloudflare, a CDN hostname,
  another server of yours); it becomes a node of its own, and the whole protocol matrix is
  published through it.

Every source carries a `location`, its own Host/SNI and a node cap; disabling or deleting a
location stops its nodes from being published, and the leftover rows are removed on the next
sync. `POST /api/edge/scan`, `POST /api/edge/sources`, `POST /api/edge/ips` and the matching
`DELETE`s are the same actions over the API.

`GET /api/edge` enriches every source with its own health — `addresses`, `nodes`, `healthy`,
`failed`, `pending`, `fastest_ms`, its measured `geo` (`country`, `counts`, `measured`, `total`,
`agree`, `flag`, `name`) and a one-line `reason`. `POST /api/edge/geo` measures the addresses
no database has answered for yet (bounded per call), re-labels the locations the data
contradicts and republishes — the same pass runs after a scan, after saving or pinging a
location, and in the monitor loop, so the catalog converges on its own. The locations table renders it as an
آی‌پی count, a `پینگ` verdict (`2/3 · 42 ms`, `ناموفق · 3`, `پینگ نشده`) and a `data-edge="ping"`
button per row, backed by **`POST /api/edge/sources/{id}/ping`**: it syncs, then probes exactly
that location's nodes the way a client would and returns the per-address results. Saving a
location, scanning a provider, adding clean IPs, toggling a location on, installing a location
pack and importing a subscription all measure the affected locations in the same request, so a
new location is never published unverified.

Icons are committed, but can be regenerated after a rebrand with:

```bash
python3 scripts/make_icons.py
```

## Verification

```bash
python -m pytest -q                        # backend + panel API + PWA asset tests
node tests/js_smoke.mjs                    # links the ES-module graph and exercises the render paths
node tests/worker_smoke.mjs                # routes every published path through the real Worker source
python scripts/check_subscriptions.py      # prints the exact matrix one user receives
python scripts/check_xray_config.py        # builds the real Xray config and runs `xray run -test`
python scripts/check_transports_e2e.py     # drives real traffic through each direct transport

# the tests that need the real engines instead of a rendered config
NEXUS_TEST_MTG_BINARY=/usr/local/bin/mtg NEXUS_TEST_XRAY_BINARY=/usr/local/bin/xray \
  python -m pytest -q tests/test_telegram.py
```

The three `check_*` scripts build their own throwaway database, so they never touch the
live one. `check_xray_config.py` needs the Xray binary (`XRAY_BIN=/usr/local/bin/xray`);
`check_transports_e2e.py` additionally proves Reality and (when `WARP_CONFIG` is supplied)
the WARP exit node actually carry traffic, and exits 0 without testing when the binary is
missing. `app/xray.py` runs the same `xray run -test` before every start and falls back to
the transports that need no raw TCP port, so a rejected optional inbound can never take the
transport every deployment already serves down.

The Python suite covers the parsers, subscription rendering, panel API, session/cookie
policy, presets, client catalog, per-node links, settings validation, node bootstrap andthe PWA assets. The Node smoke test does not need a browser or a build step.

`tests/test_telegram.py` is the exception that does not trust the config it renders: with the
pinned `mtg` and `xray` binaries present it runs `mtg access` against the real rendered file,
starts the real listener, and has Xray `-test` the HTTP/SOCKS5 inbounds it generated; without
the binaries those cases skip, so the suite stays runnable anywhere. The Telegram Web proxy is
proved by the allowlist tests (an unlisted host must not be proxied at all) and by the Worker
smoke test, which routes `/tg/…` through the real Worker source.

Initial panel password: `admin` — change it right after the first login. Do not expose the
Xray API port publicly; it is bound to loopback.
